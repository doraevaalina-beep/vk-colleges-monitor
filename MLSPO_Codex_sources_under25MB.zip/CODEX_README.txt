MLSPO Codex source bundle
Contains the 8 original editable square SVG templates (1080x1080) and non-font brand resources.
Use SVG files as the only design masters. Do not reconstruct or trace PNG/EPS.
Expected editable groups in SVG: PHOTO_REPLACE, HEADLINE_TEXT, DETAIL_TEXT, PHOTO_HINT.
Font file is intentionally not bundled here; preserve the Onest font-family declared by the originals and configure it separately from an authorized/public source during implementation.
